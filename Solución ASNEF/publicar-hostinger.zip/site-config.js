window.SITE_CONFIG = {
  brandMark: 'SA',
  siteName: 'Soluci\u00f3n ASNEF',
  siteUrl: 'https://www.solucionasnef.com',
  ogImage: 'https://www.solucionasnef.com/logo-icono.png',
  publicContactEmail: 'contacto@solucionasnef.com',
  publicContactPhone: '+34 660566880',
  supportSchedule: 'Todos los d\u00edas de 8:00 a 20:00',
  ownerName: 'Anthony Correa Iser',
  taxId: '60535430M',
  legalAddress: 'C. los Perales, 3, 35018 Las Palmas de Gran Canaria, Las Palmas',
  privacyEmail: 'privacidad@solucionasnef.com',
  analyticsProvider: 'Google Analytics 4',
  cookieManager:
    'Banner propio con rechazo y aceptaci\u00f3n. Si activas anuncios personalizados en EEE, completa tambi\u00e9n la CMP certificada desde Google AdSense.',
  formProcessorName: 'Formspree',
  leads: {
    enabled: true,
    responseWindow: '24 horas laborables',
    destinationLabel: 'Bandeja privada de revisi\u00f3n',
    disclaimer:
      'La orientaci\u00f3n inicial es informativa y no sustituye asesoramiento jur\u00eddico o financiero individualizado.',
  },
  analytics: {
    enabled: false,
    measurementId: '',
  },
  ads: {
    enabled: false,
    provider: 'Google AdSense',
    adsenseClient: '',
    topBannerSlot: '',
    inContentSlot: '',
    bottomSlot: '',
  },
  cookieBanner: {
    enabled: true,
  },
  accounts: {
    enabled: true,
  },
};
